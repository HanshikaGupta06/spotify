import React from 'react'
import Rolling from './component/Rolling'
import { Box } from './component/Box'
import Sidebar from './component/Sidebar'

const App = () => {
  const heading = 'TRENDING'

  return (
    <div className="bg-black text-white flex w-full h-screen">
      {/* Main content section */}
      <div className="flex flex-col overflow-auto">
        <Box />
        <Rolling heading={heading} />
      </div>

      {/* Sidebar positioned to the right */}
      <div className="w-[300px] h-full">
        <Sidebar />
      </div>
    </div>
  )
}

export default App

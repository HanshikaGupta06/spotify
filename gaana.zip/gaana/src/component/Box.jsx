import React from 'react'
import image from '../images/image1.png'
import { Elem } from './Elem'

export const Box = () => {
    const img = image;
   
  return (
    <div className='flex flex-wrap gap-10 p-5'>
        <Elem img={img} color='bg-teal-300' description="Description"/>
        <Elem img={img} color='bg-pink-300' description="Likes"/>
        <Elem img={img} color='bg-yellow-300' description="Favourites"/>
        <Elem img={img} color='bg-blue-300' description="Recently played"/>

    </div>
  )
}

import React from 'react'
import SideImage from './SideImage'
import img from '../images/image1.png'

const Sidebar = () => {
  return (
    <div className='flex  flex-col overflow-scroll h-screen m-2 p-2'>
        <SideImage img={img} name='SHREYA GHOSAL'  descr='Hey i am shreya ghosal sings a vahiyaat song for u guys' follower='34' />
        <SideImage img={img}name='KAILASH KHER'  descr='Hey i am your fav singer a best song for u guys' follower='34'/>
        <SideImage img={img}name='ARJIT SINGH'  descr='Hey i am sings a  song for u guys' follower='34'/>

        


    </div>
  )
}

export default Sidebar
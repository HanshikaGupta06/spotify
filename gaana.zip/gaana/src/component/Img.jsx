import React from 'react'

const Img = (hg) => {
  const src = hg.src;
  const title = hg.title;
  const composition = hg.composition;
  return (
    <div className='w-50 rounded-lg p-5'>
      <img className='rounded-lg hover:scale-105 transition-all duration-700 cursor-pointer ' src={src} alt="" />
      <div className='m-2'>
        <h1 className='text-2xl text-white font-bold '>{title}</h1> 
        <p className='text-xl text-white font-thin'>{composition}</p>
      </div>
    </div>
  )
}

export default Img 
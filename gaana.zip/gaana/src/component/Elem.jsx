import React from 'react'

export const Elem = (props) => {
    const ig = props.img;
    const description=props.description;
    const color=props.color;
  return (
    <div className={`text-white flex rounded-lg w-[30%] ${color}`}>
        <img className='w-15 h-15 rounded-lg' src={ig} alt=""  />
        <p className='text-xl font-bold m-3 text-black'>{description}</p>
    </div>
  );

}

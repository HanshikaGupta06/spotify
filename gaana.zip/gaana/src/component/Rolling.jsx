import React from 'react'
import Img from './Img'
import hg from '../images/image1.png'


const Rolling = (props) => {
  const heading=props.heading;

  const title = "Perfect";
  const composition="Hanshika decomposed it";
  return (
    <>
    <h1 className='text-white text-2xl font-bold text-center pt-5'> {heading}</h1>
    <div className='flex p-4 gap-10 overflow-scroll '>
      <Img src={hg} title={title} composition={composition} />
      <Img src={hg} title={title} composition={composition} />
      <Img src={hg} title={title} composition={composition} />
      <Img src={hg} title={title} composition={composition} />
      <Img src={hg} title={title} composition={composition} />
      <Img src={hg} title={title} composition={composition} />
      <Img src={hg} title={title} composition={composition} />
      <Img src={hg} title={title} composition={composition} />
    </div>
    </>
  )
}

export default Rolling
import React from 'react'

const SideImage = (props) => {
    const img = props.img;
    const name = props.name;
    const follower = props.follower;
    const descr = props.descr;
    return (
        <div className='w-80 p-5 bg-gray-800 mt-2 rounded-lg'>
            <img className='w-65 rounded-lg' src={img} alt="" />
            <h1 className='font-bold'>{name}</h1>
            <div className='flex justify-between pl-2 pr-2'>
            <p>{follower}</p>
            <button className='cursor-pointer border-1 rounded-lg p-1'>like button</button>
            </div>
            
            <p>{descr}</p>
        </div>
    )
}

export default SideImage